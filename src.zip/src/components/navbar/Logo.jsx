import logo from '../../logo.svg';

const Logo = () => {
    return (
        <img src={logo} alt="logo" width= "50" height ="50" />
    )
}

export default Logo;