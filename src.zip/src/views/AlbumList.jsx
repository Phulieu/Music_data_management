import {  useEffect, useState } from "react";

import { AgGridReact } from "ag-grid-react";

import apiCalls from "../api";
import styled from "styled-components";

const Div = styled.div.attrs({
    className: 'ag-theme-alpine'
})`
    height: 70vh;
    witdth: 1080px;
    margin: auto;
`;

const AlbumList = () => {

    const [albums, setAlbums] = useState();

    useEffect(()=> {
        apiCalls.getAllAlbums().then(
            (res) => {
                setAlbums(res.data.data);
            }
        ).catch(console.error);
    },[]);

    const col = [
        {field: 'album'},
        {field: 'artist'},
        {field: 'year'},
        {field: 'artwork'}
    ];

   
    return(
        <Div>
            <AgGridReact 
                rowData = {albums}
                columnDefs={col} 
                
            />
        </Div>
    )
}

export default AlbumList;